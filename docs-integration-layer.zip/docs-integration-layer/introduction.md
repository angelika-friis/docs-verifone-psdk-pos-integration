---
id: introduction
title: Introduction
slug: /
---

# The Integration Layer

The integration layer is the application's public interface towards the terminal, payments, scanner, and printing.  
The application layer must use the `TerminalApi` contract.  
The Verifone Payment SDK or internal implementations must not be used directly by the application layer.

## Start reading

Choose your use case:
- Run the existing POS application → [Run the POS application](run-pos-app.md)
- Build your own POS application → [Build your own POS application](build-pos-app.md)
- Develop the integration layer → [Architecture](architecture.md)

## When you need more

The features are described separately:

- [Payments](features/payments.md)
- [Refund](features/refund.md)
- [Void](features/void.md)
- [Scanner](features/scanner.md)
- [Receipt printing](features/receipt-printing.md)

Known limitations are listed in [Limitations](limitations.md).

Internal architecture and implementation are described in [Architecture](architecture.md) and  
[Internal overview](internal/overview.md). These documents are intended for developers of the integration layer.

Handle state according to [State and flows](api/state-and-flows.md).
Handle results and errors according to [Error handling](error-handling.md).